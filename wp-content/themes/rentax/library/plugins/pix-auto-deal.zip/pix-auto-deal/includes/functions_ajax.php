<?php
// Exit if accessed directly

if( ! defined( 'ABSPATH' ) ) exit;

include_once(plugins_url().'/pix-auto-deal/classes/class.pixad-autos.php');
global $post, $PIXAD_Autos;

$Query = false;

print_r($PIXAD_Autos);


?>